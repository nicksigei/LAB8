package dWp8;

public class Dwp8Class {
public int sum(int a, int b)
{
	return a+b;
}
}
